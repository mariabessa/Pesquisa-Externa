# Pesquisa Externa
 Trabalho Prático da disciplina Estutura de Dados II da Universidade Federal de Ouro Preto
