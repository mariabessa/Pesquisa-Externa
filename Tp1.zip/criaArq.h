# ifndef criaArq_h
# define criaArq_h
#include <stdio.h>

char* generateRandomString(int);
void arquivo();

# endif